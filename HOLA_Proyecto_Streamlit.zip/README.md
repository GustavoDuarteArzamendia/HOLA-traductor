# Proyecto HOLA
Una app de traducción en tiempo real.